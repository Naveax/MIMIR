#!/usr/bin/env python3
from pathlib import Path
import json, hashlib, re

BASE_SHA = "b8e9bb465bd49974ca23e00c42ea29d59beecb39"
BASE_TREE = "7480a997259b5f77a88e1326da2ccfbebe801f80"
PROD_SHA = "e1ccbef95c8424b689dee7d77fd8fde2af3e0204"
PROD_TREE = "4e7100625096594bcc5c5b4c6a8054c283643b13"
CONTRACT_SHA = "3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5"

CONTRACT_TEXT = '{\n  "schema_version": 1,\n  "contract": "MIMIR_R3_18AT_POST_AQ_MIXED_CONTINUATION_FOLLOWING_HEADER_CONTEXTS",\n  "status": "admitted",\n  "admission_date": "2026-08-26",\n  "boundary": "exactly one existing-actor following property header after a valid published R3.18AQ true control on the immutable R3.18AS continuation sublane; false controls terminate before header membership",\n  "membership_policy": "exact_tuple_only",\n  "tuple_fields": [\n    "stream_id_bound",\n    "prop_id_bits",\n    "property_object_index",\n    "attribute_tag",\n    "version_major",\n    "version_minor",\n    "net_version",\n    "is_rl_223"\n  ],\n  "frozen_lane_row_count": 47,\n  "false_terminator_count": 7,\n  "observed_header_row_count": 40,\n  "unique_exact_context_count": 16,\n  "authority": {\n    "canonical_main_sha": "b8e9bb465bd49974ca23e00c42ea29d59beecb39",\n    "canonical_main_tree": "7480a997259b5f77a88e1326da2ccfbebe801f80",\n    "production_sha": "e1ccbef95c8424b689dee7d77fd8fde2af3e0204",\n    "production_tree": "4e7100625096594bcc5c5b4c6a8054c283643b13",\n    "production_parent": "ec2d6c29f90863d9e312856043d01fb98a0c2d2d",\n    "production_lib_blob": "b886c58400de0efe0a6a6113d79e6f78e751a213",\n    "production_aq_test_blob": "983cbda666f40cbc739b250eac87bc4ce0c9eb99",\n    "r3_18as_execution_spec_blob": "4b69c75012a7a358522b3399c1e943d537339838",\n    "r3_18as_decision_blob": "8acdd1c4a3ba2a904e9a731bc5e82e7ac50f67e8",\n    "r3_18at_execution_spec_blob": "479ea581972f74808bf6bb6b041e7087ac672879",\n    "r3_18as_evidence_head": "475650fea59332f74b9f69da50e3e4471622ab7e",\n    "r3_18as_evidence_tree": "1303071ad3031f4095e29d775afd243286a67b64",\n    "r3_18as_run": 32959321642,\n    "r3_18as_job": 98147938829,\n    "r3_18as_same_head_ci_run": 32959321531,\n    "r3_18as_same_head_ci_job": 98147938016,\n    "r3_18as_artifact_id": 9603335255,\n    "r3_18as_artifact_size": 13250,\n    "r3_18as_artifact_sha256": "0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45",\n    "r3_18as_manifest_sha256": "638f314ea585aa0ad33ea0b2ca7417687139fd67f4a27e04813348210009ae4a",\n    "r3_18as_header_rows_sha256": "b7f9b50935aa559011152c0722a24441d590f262ff2a69e85a51636605b89086",\n    "r3_18as_header_summary_sha256": "ecb49bf9ee38d4249b3e6d91c5dec7ceb2288b6ed6452dbbb3dce3304d371a38",\n    "r3_18as_continuation_targets_sha256": "3733514eeceea2ae80b5a4a6c3435c210ab3268901bae7be39e9ab1152860900",\n    "r3_18as_terminator_rows_sha256": "1af0a82eb9ba5a7b65755a99959f1754e1839db0cc61d90eb414e3ee9fedef27",\n    "r3_18as_negative_controls_sha256": "653f6184b0731a9ab4dde9e2188ef19377fa2ab1412fbfbf067dca7a1894ea9e",\n    "r3_18as_validation_sha256": "75aedf9309f5fc78ecec8b51bf0d19ccabab8b475f6fe7beeddf0b6160cae78c",\n    "r3_18as_aggregate_sha256": "913156d675c8e106c8428a02ec6b42f54e31dcdd5f9fdc24cba10ef1fc935cab",\n    "r3_18as_publication_run": 32967201830,\n    "r3_18as_publication_job": 98172273710,\n    "r3_18as_publication_artifact": 9606191056,\n    "r3_18as_publication_artifact_sha256": "1d35bd5228d9a186b99eb93c0cd60a86b3714521c7a56c15feb28934656b72e6",\n    "pinned_boxcars_sha": "c70e77df7af81b436cb545d070bb90c82f562d0b",\n    "boxcars_instrumentation_patch_sha256": "abd386097cc2bd22bdd685f67c13687cd6a3330b12944a43d8d30da109a8e50e",\n    "witness_reselection": 0,\n    "native_oracle_mismatch": 0,\n    "following_payload_bits_consumed": 0,\n    "second_later_control_bits_consumed": 0\n  },\n  "observed_tag_counts": {\n    "Int": 40\n  },\n  "admitted_contexts": [\n    {\n      "stream_id_bound": 110,\n      "prop_id_bits": 6,\n      "property_object_index": 49,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 106,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 4\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 107,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 19\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 113,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 115,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 2\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 117,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 122,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 130,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 2\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 131,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 134,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 144,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 60,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 60,\n      "prop_id_bits": 5,\n      "property_object_index": 69,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 2\n    },\n    {\n      "stream_id_bound": 67,\n      "prop_id_bits": 6,\n      "property_object_index": 81,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 72,\n      "prop_id_bits": 6,\n      "property_object_index": 84,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    },\n    {\n      "stream_id_bound": 72,\n      "prop_id_bits": 6,\n      "property_object_index": 87,\n      "attribute_tag": "Int",\n      "version_major": 868,\n      "version_minor": 32,\n      "net_version": 10,\n      "is_rl_223": false,\n      "observed_count": 1\n    }\n  ],\n  "terminator_policy": {\n    "false_rows_are_terminators": true,\n    "false_terminator_count": 7,\n    "false_terminators_produce_header_membership": false\n  },\n  "anti_widening": {\n    "tag_only_membership": false,\n    "component_only_membership": false,\n    "cartesian_product_membership": false,\n    "versionless_membership": false,\n    "rl223_field_dropped_membership": false,\n    "rl223_false_to_true_membership": false,\n    "r3_18aj_cross_boundary_inheritance": false,\n    "r3_18z_cross_boundary_inheritance": false,\n    "r3_18p_cross_boundary_inheritance": false,\n    "false_terminator_header_synthesis": false,\n    "fabricated_seventeenth_tuple_admitted": false,\n    "multiplicity_is_runtime_frequency_promise": false,\n    "contexts_outside_exact_set_admitted": false\n  }\n}\n'
DECISION_TEXT = "# MIMIR R3.18AT — Post-AQ Mixed-Continuation Following-Header Exact-Context Contract Decision\n\n**Date:** 2026-08-26\n**Outcome:** **A — ADMITTED / BOUNDARY-SPECIFIC EXACT-EIGHT-FIELD CONTRACT**\n**Production mutation:** none\n**Canonical production:** `e1ccbef95c8424b689dee7d77fd8fde2af3e0204` / `4e7100625096594bcc5c5b4c6a8054c283643b13`\n**Contract:** `docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json`\n**Contract SHA-256:** `3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5`\n\n## Decision\n\nR3.18AT closes Outcome A. The immutable R3.18AS mixed-continuation following-header observation has been crystallized into a boundary-specific contract containing exactly **16 complete eight-field tuples** with exact observed multiplicities summing to **40**. Membership is `exact_tuple_only`. All forty admitted header rows are `Int`.\n\nThe seven R3.18AQ false rows remain successful terminators and are explicitly outside following-header membership. `is_rl_223` is retained as the eighth tuple field even though all current AS rows are false. Earlier R3.18AJ, R3.18Z and R3.18P contracts are methodology/history only and are not inherited or unioned at this boundary.\n\n## Exact authority\n\n```text\ncanonical main before admission       b8e9bb465bd49974ca23e00c42ea29d59beecb39 / 7480a997259b5f77a88e1326da2ccfbebe801f80\nproduction SHA/tree                   e1ccbef95c8424b689dee7d77fd8fde2af3e0204 / 4e7100625096594bcc5c5b4c6a8054c283643b13\nproduction parent                     ec2d6c29f90863d9e312856043d01fb98a0c2d2d\nproduction lib / AQ test blobs        b886c58400de0efe0a6a6113d79e6f78e751a213 / 983cbda666f40cbc739b250eac87bc4ce0c9eb99\nAS execution spec / decision blobs    4b69c75012a7a358522b3399c1e943d537339838 / 8acdd1c4a3ba2a904e9a731bc5e82e7ac50f67e8\nAT execution spec blob                479ea581972f74808bf6bb6b041e7087ac672879\nAS evidence head/tree                 475650fea59332f74b9f69da50e3e4471622ab7e / 1303071ad3031f4095e29d775afd243286a67b64\nAS authority run/job                  32959321642/98147938829 SUCCESS\nAS same-head natural CI               32959321531/98147938016 SUCCESS\nAS artifact                           9603335255 / 13250 bytes / sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45\nAS manifest SHA-256                   638f314ea585aa0ad33ea0b2ca7417687139fd67f4a27e04813348210009ae4a\nAS header rows / summary SHA-256      b7f9b50935aa559011152c0722a24441d590f262ff2a69e85a51636605b89086 / ecb49bf9ee38d4249b3e6d91c5dec7ceb2288b6ed6452dbbb3dce3304d371a38\nAS continuation / terminator SHA-256  3733514eeceea2ae80b5a4a6c3435c210ab3268901bae7be39e9ab1152860900 / 1af0a82eb9ba5a7b65755a99959f1754e1839db0cc61d90eb414e3ee9fedef27\nAS canonical publication              32967201830/98172273710 SUCCESS\nAS publication receipt artifact       9606191056 / sha256:1d35bd5228d9a186b99eb93c0cd60a86b3714521c7a56c15feb28934656b72e6\npinned Boxcars                        c70e77df7af81b436cb545d070bb90c82f562d0b\n```\n\nThe R3.18AS ZIP was independently downloaded and its SHA-256 matched GitHub's artifact digest. Its internal manifest hash is the value above and all 13 listed payload entries verify.\n\n## Admitted contract\n\n```text\nmembership policy                    exact_tuple_only\ntuple fields                         stream_id_bound, prop_id_bits, property_object_index, attribute_tag, version_major, version_minor, net_version, is_rl_223\nfrozen lane rows                     47\nfalse terminators                    7 / outside header membership\nobserved header rows                 40\nexact contexts                       16/16\nobserved multiplicity sum            40\nobserved tags                        Int=40\nwitness reselection                  0\nnative/oracle mismatch               0\nfollowing payload / second control   0/0\nAJ/Z/P inheritance                   false/false/false\n```\n\nThe exact tuple identities and multiplicities are authoritative only through the JSON contract named above.\n\n## Anti-widening validation\n\n```text\nexact tuple equality                 PASS 16/16\nexact multiplicity equality          PASS 16/16 / sum 40\nfalse terminators outside membership PASS 7/7\ntag-only membership                  REJECT\ncomponent-only membership            REJECT\nCartesian candidate                  REJECT: (110,5,107,Int,868,32,10,false)\nversion/RL223-dropping candidate     REJECT\nRL223 false->true candidate          REJECT\nfabricated seventeenth tuple         REJECT: (60,5,999,Int,868,32,10,false)\nAJ-valid AT-absent tuple             REJECT: (60,5,38,Int,868,32,10,false)\nproduction/Cargo/fixture/corpus/support mutation 0/0/0/0/0\n```\n\nMultiplicity is evidence provenance, not a runtime-frequency promise.\n\n## Hard stop\n\nR3.18AT admits a contract only. It does not publish a post-AQ following-header composition, decode the following payload, read a second later property-control bit, synthesize a header on a false terminator, authorize a generalized/repeated property loop/cursor, advance actor/frame/lifecycle state, materialize raw state/events, slice replays, mine skills, execute counterfactuals or widen runtime/export behavior.\n\n## Next gate\n\nR3.18AU is a separate bounded production pass. It may validate/recompute one exact published R3.18AQ result. A false AQ result must remain a successful terminator with no following-header lookup. A true AQ result may compose exactly one following existing-actor property header with the existing stateless primitive, must require exact R3.18AT eight-field membership, and must stop exactly at `payload_start`. It may not decode the payload or another control.\n"
AU_SPEC_TEXT = '# MIMIR R3.18AU — Bounded Post-AQ Mixed-Continuation Following-Header Production\n\n**Status:** ACTIVE\n**Pass type:** bounded production implementation\n**Production authority before pass:** R3.18AQ `e1ccbef95c8424b689dee7d77fd8fde2af3e0204` / `4e7100625096594bcc5c5b4c6a8054c283643b13`\n**Contract authority:** R3.18AT Outcome A / `docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json`\n**Contract SHA-256:** `3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5`\n**Following payload decode:** forbidden\n**Second later property-control bit:** forbidden\n**Generalized/repeated property loop:** forbidden\n\n## 1. Goal\n\nPublish the minimum boundary-specific composition after one valid published R3.18AQ mixed control result.\n\n- If the validated AQ result is `property_present == false`, preserve it as a successful terminator and perform **no following-header lookup or wire consumption**.\n- If the validated AQ result is `property_present == true`, decode exactly one following existing-actor property header with the existing stateless header primitive, require exact R3.18AT eight-field tuple membership, expose that header identity, and stop exactly at `payload_start`.\n\nNo following payload or later control may be consumed.\n\n## 2. Frozen authority\n\n```text\ncanonical continuity parent           b8e9bb465bd49974ca23e00c42ea29d59beecb39 / 7480a997259b5f77a88e1326da2ccfbebe801f80\nproduction SHA/tree                   e1ccbef95c8424b689dee7d77fd8fde2af3e0204 / 4e7100625096594bcc5c5b4c6a8054c283643b13\nproduction parent                     ec2d6c29f90863d9e312856043d01fb98a0c2d2d\nproduction lib / AQ test blobs        b886c58400de0efe0a6a6113d79e6f78e751a213 / 983cbda666f40cbc739b250eac87bc4ce0c9eb99\nAS evidence head/tree                 475650fea59332f74b9f69da50e3e4471622ab7e / 1303071ad3031f4095e29d775afd243286a67b64\nAS authority run/job                  32959321642/98147938829 SUCCESS\nAS artifact                           9603335255 / sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45\nAT exact contract                     sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5\nAT membership                         exact_tuple_only / 16 eight-field tuples / multiplicity 40\nfrozen mixed lane                     47 rows / false=7 / true=40\nobserved true-header tags              Int=40\npinned Boxcars                        c70e77df7af81b436cb545d070bb90c82f562d0b\n```\n\nR3.18AT, not resemblance to R3.18AJ/Z/P, is the sole following-header context authority at this boundary.\n\n## 3. Production contract\n\nThe new boundary-specific API must:\n\n1. validate/recompute the supplied published R3.18AQ prior instead of trusting arbitrary caller coordinates;\n2. require exact equality of AQ control start/end/stop with the recomputed prior;\n3. branch on the validated AQ boolean without re-reading that control;\n4. on `false`, return a terminator/no-header result and perform zero stream/header/payload/later-control reads;\n5. on `true`, invoke the existing stateless existing-actor header primitive exactly once at the validated AQ stop;\n6. retain all eight R3.18AT context fields, including `is_rl_223`;\n7. require exact membership in the R3.18AT contract, with no tag/component/Cartesian/versionless/RL223-dropped membership;\n8. require returned header `property_present == true` and exact alignment to the AQ control boundary;\n9. expose exact stream/header/property/tag/context coordinates and set final stop exactly to `payload_start`;\n10. consume zero following-payload bits and zero second-later-control bits.\n\nThe API must not expose a repeatedly-chainable cursor or generic property loop.\n\n## 4. Required focused tests\n\nAt minimum:\n\n- exact immutable 47-row mixed lane: 7 false terminators + 40 true headers;\n- false path succeeds without header lookup and without any post-AQ bit consumption;\n- true path succeeds 40/40 and exact AT membership is 40/40;\n- all 16 exact contexts exercised with multiplicities matching frozen evidence;\n- deterministic repeatability;\n- truncation inside a true-row following header rejects atomically;\n- wrong actor object rejects;\n- unresolved stream/property lookup rejects;\n- wrong exact version/context rejects;\n- `is_rl_223` false->true mutation rejects;\n- tag-only/component-only/Cartesian/versionless candidate rejects;\n- AJ-valid but AT-absent `(60,5,38,Int,868,32,10,false)` rejects;\n- fabricated seventeenth tuple rejects;\n- post-`payload_start` poison leaves the true-path header result unchanged;\n- following payload and second later control consumption remain `0/0`;\n- source-scope guard proves at most one header primitive call, zero payload decoders and no generalized/repeated property loop.\n\nSynthetic tests supplement but do not widen the immutable AS/AT authority.\n\n## 5. Clean candidate\n\nThe clean production commit must contain only the minimum `crates/mimir-replay/src/lib.rs` change plus one focused R3.18AU integration test file. No workflow/helper, evidence artifact, Cargo/dependency, fixture/corpus, continuity, raw-state/event/skill/runtime/export or unrelated cleanup may enter the production commit.\n\n## 6. Validation and publication\n\nRequire:\n\n- Rust 1.85 formatting;\n- focused AU tests;\n- directly affected AQ/AN/header prerequisite regressions;\n- workspace check;\n- workspace test;\n- clippy with warnings denied;\n- repository verifier;\n- exact clean-candidate normal CI;\n- fresh-main ancestry verification;\n- force-free publication;\n- exact published-main SHA/tree readback;\n- published-main validation on the exact published SHA.\n\nBefore any dispatch/rerun, inspect queued/waiting/in-progress equivalent runs. Reuse the existing run ID when equivalent. Rerun is never polling.\n\n## 7. Hard stop\n\nNo following payload after the one admitted header, no second later property-control bit, no context outside the exact R3.18AT contract, no following-header synthesis for a false terminator, no generalized/repeated property loop/cursor, no next actor/frame/lifecycle mutation, no raw-state/event/replay-slice/skill/counterfactual/runtime/export widening.\n\n## 8. Outcome gate\n\n### Outcome A\n\nThe exact 7 false terminators remain no-header successes; the exact 40 true rows compose one header matching the R3.18AT contract; all focused/negative/full validations pass; payload/second-control consumption stays `0/0`. Publish only this bounded mixed-continuation composition. Then open a separate published-production differential pass.\n\n### Outcome B\n\nOnly a strict safe subset or narrower result representation can be implemented without violating R3.18AT. Publish only that exact subset/representation and rewrite the next differential accordingly.\n\n### Outcome C\n\nAuthority drift, false-terminator header access, context/RL223 widening, payload/later-control access, generic chaining, production-scope drift or validation contradiction. Stop without publication.\n'

def read(path):
    return Path(path).read_text(encoding="utf-8")

def write(path, text):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text.rstrip() + "\n", encoding="utf-8")

def sub_once(text, pattern, repl, label, flags=0):
    new, n = re.subn(pattern, repl, text, count=1, flags=flags)
    if n != 1:
        raise SystemExit(f"{label} replacement count={n}")
    return new

# 1) Contract + decision + AU spec
if hashlib.sha256(CONTRACT_TEXT.encode()).hexdigest() != CONTRACT_SHA:
    raise SystemExit("contract text hash drift")
write("docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json", CONTRACT_TEXT)
write("docs/continuity/MIMIR_R3_18AT_DECISION.md", DECISION_TEXT)
write("docs/continuity/MIMIR_R3_18AU_EXECUTION_SPEC.md", AU_SPEC_TEXT)

# 2) Master continuity handbook
p = "MIMIR_CONTINUE_HERE.md"
t = read(p)
t = sub_once(
    t,
    r"(?m)^LAST_COMPLETED_CONTRACT_PASS:\n  .*\n",
    "LAST_COMPLETED_CONTRACT_PASS:\n  R3.18AT — post-AQ mixed-continuation following-header exact-context contract / Outcome A / 16 exact eight-field tuples / multiplicity 40 / 7 false terminators outside membership / contract 3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5 / AJ-Z-P inheritance false / RL223 retained\n",
    "continue last contract",
)
t = sub_once(
    t,
    r"(?m)^CURRENT_PASS:\n  .*\n",
    "CURRENT_PASS:\n  R3.18AU — bounded post-AQ mixed-continuation following-header production\n",
    "continue current pass",
)
t = sub_once(
    t,
    r"(?m)^CURRENT_PASS_TYPE:\n  .*\n",
    "CURRENT_PASS_TYPE:\n  bounded production implementation / validate-recompute one published R3.18AQ mixed control; false remains a no-header terminator; true may compose exactly one stateless following header only under exact R3.18AT eight-field membership; stop at payload_start with payload/second-control consumption zero\n",
    "continue current pass type",
)
old_frontier = (
    "  R3.18AS CLOSED Outcome A: frozen split exact 47/47; 7/7 false terminators; 40/40 true one-header observations exact through payload_start; 16 complete eight-field contexts; Int=40; mismatch/reselection 0/0; payload/second-control 0/0\n"
    "  R3.18AT ACTIVE contract-only: freeze only those exact 16 eight-field tuples and their exact multiplicities on the 40 true rows; false terminators remain outside header membership\n"
    "  NO production following-header composition before AT contract admission, following payload, second later property-control bit, header on false terminators, generalized/repeated property loop/cursor, next actor/frame/lifecycle/raw-state/event/replay-slice/skill/runtime/export widening is admitted\n"
)
new_frontier = (
    "  R3.18AS CLOSED Outcome A: frozen split exact 47/47; 7/7 false terminators; 40/40 true one-header observations exact through payload_start; 16 complete eight-field contexts; Int=40; mismatch/reselection 0/0; payload/second-control 0/0\n"
    "  R3.18AT CLOSED Outcome A: exact_tuple_only 16 complete eight-field contexts / multiplicity sum 40 / 7 false terminators outside membership / contract 3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5 / AJ-Z-P inheritance false / RL223 retained\n"
    "  R3.18AU ACTIVE bounded production: false AQ prior remains a no-header terminator; true prior may compose exactly one stateless following header only under exact R3.18AT membership and stop at payload_start\n"
    "  NO following payload or second later property-control bit after the R3.18AU header boundary, header on false terminators, generalized/repeated property loop/cursor, next actor/frame/lifecycle/raw-state/event/replay-slice/skill/runtime/export widening is admitted\n"
)
if old_frontier not in t:
    raise SystemExit("continue frontier anchor missing")
t = t.replace(old_frontier, new_frontier, 1)
closure = """R3_18AT_CONTRACT_CLOSURE:
Outcome A / contract-only admission / production unchanged at e1ccbef95c8424b689dee7d77fd8fde2af3e0204
canonical main before admission: b8e9bb465bd49974ca23e00c42ea29d59beecb39 / tree 7480a997259b5f77a88e1326da2ccfbebe801f80
AS evidence head/tree: 475650fea59332f74b9f69da50e3e4471622ab7e / 1303071ad3031f4095e29d775afd243286a67b64
AS authority run/job: 32959321642/98147938829 SUCCESS / same-head CI 32959321531/98147938016 SUCCESS
AS artifact: 9603335255 / 13250 bytes / sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45 / manifest 13/13 PASS
AS canonical publication: 32967201830/98172273710 SUCCESS / receipt 9606191056 / sha256:1d35bd5228d9a186b99eb93c0cd60a86b3714521c7a56c15feb28934656b72e6
contract: docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json / sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5
membership exact_tuple_only / tuple fields bound, prop-width, object, tag, version-major/minor, net-version, is_rl_223
frozen rows 47 / false terminators 7 outside membership / true header rows 40 / exact contexts 16 / multiplicity sum 40 / Int=40
exact tuple + multiplicity equality PASS / tag-only, component-only, Cartesian, versionless, RL223-drop/flip, fabricated-17th, AJ-valid-AT-absent negatives REJECT
production/Cargo/fixture/corpus/support mutation 0/0/0/0/0
next exact pass: R3.18AU bounded post-AQ mixed-continuation following-header production; no payload or later control
"""
marker = "R3_18AS_EVIDENCE_CLOSURE:"
if "R3_18AT_CONTRACT_CLOSURE:" in t:
    raise SystemExit("AT closure already present")
if marker not in t:
    raise SystemExit("AS closure marker missing")
t = t.replace(marker, closure + "\n" + marker, 1)
write(p, t)

# 3) Knowledge graph
p = "MIMIR_KNOWLEDGE_GRAPH.md"
t = read(p)
old = "R3.18AT post-AQ mixed-continuation following-header exact-context contract / ACTIVE                         |"
new = (
    "R3.18AT post-AQ mixed-continuation following-header exact-context contract / Outcome A CLOSED               |\n"
    "R3.18AU bounded post-AQ mixed-continuation following-header production / ACTIVE                              |"
)
if old not in t:
    raise SystemExit("KG graph frontier missing")
t = t.replace(old, new, 1)

start = t.index("## Mandatory reading order")
end = t.index("\n\n### ", start)
sec = t[start:end]
paths = re.findall(r"(?m)^\d+\. `([^`]+)`$", sec)
if len(paths) != 135:
    raise SystemExit(f"mandatory order expected 135 got {len(paths)}")
anchor = "docs/continuity/MIMIR_R3_18AT_EXECUTION_SPEC.md"
idx = paths.index(anchor) + 1
insert = [
    "docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json",
    "docs/continuity/MIMIR_R3_18AT_DECISION.md",
    "docs/continuity/MIMIR_R3_18AU_EXECUTION_SPEC.md",
]
for off, item in enumerate(insert):
    if item not in paths:
        paths.insert(idx + off, item)
newsec = "## Mandatory reading order\n\n" + "\n".join(f"{i}. `{path}`" for i, path in enumerate(paths, 1))
t = t[:start] + newsec + t[end:]

at_section = f"""### R3.18AT post-AQ mixed-continuation following-header exact-context contract: OUTCOME A / CLOSED
- contract `sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5` / membership `exact_tuple_only`
- exactly 16 complete eight-field tuples; exact observed multiplicities sum to 40; all observed tags Int=40
- tuple fields `(stream_id_bound, prop_id_bits, property_object_index, attribute_tag, version_major, version_minor, net_version, is_rl_223)`
- exact 7 false AQ rows remain terminators outside header membership
- exact tuple/multiplicity equality PASS; tag/component/Cartesian/versionless/RL223-drop-or-flip/fabricated/AJ-valid-AT-absent negatives reject
- AS evidence `475650fea59332f74b9f69da50e3e4471622ab7e`; artifact `9603335255`; production remains R3.18AQ
- AJ/Z/P cross-boundary inheritance false; following payload/second-control access 0/0; production mutation 0

### R3.18AU bounded post-AQ mixed-continuation following-header production: ACTIVE
- validate/recompute exactly one published R3.18AQ mixed control prior
- false prior remains a successful no-header terminator with zero post-AQ reads
- true prior may invoke the existing stateless following-header primitive exactly once
- require exact R3.18AT eight-field membership; stop exactly at `payload_start`
- following payload, second later control, generalized/repeated loop/cursor and wider semantic/runtime layers remain closed
"""
t, n = re.subn(
    r"(?ms)^### R3\.18AT post-AQ mixed-continuation following-header exact-context contract: ACTIVE\n.*?(?=\n### R3\.18AG)",
    at_section.rstrip(),
    t,
    count=1,
)
if n != 1:
    raise SystemExit(f"KG AT section replacement count={n}")
write(p, t)

# 4) Boundary locks top override
p = "docs/continuity/MIMIR_BOUNDARY_LOCKS.md"
t = read(p)
prefix, rest = t.split("# 0. Current override", 1)
_, tail = rest.split("# 1. Status vocabulary", 1)
override = f"""# 0. Current override — R3.18AT closed / R3.18AU active

This current override supersedes older status wording later in this historical lock file.

## PRODUCTION — R3.18AQ
- `e1ccbef95c8424b689dee7d77fd8fde2af3e0204` / `4e7100625096594bcc5c5b4c6a8054c283643b13` remains canonical production; parent `ec2d6c29f90863d9e312856043d01fb98a0c2d2d`;
- validates/recomputes one exact R3.18AN prior, consumes exactly one AP-admitted mixed `property_present` bit, accepts false and true, and stops one bit later;
- immutable published behavior remains false=7 / true=40.

## CLOSED EVIDENCE — R3.18AS Outcome A
- evidence `475650fea59332f74b9f69da50e3e4471622ab7e` / `1303071ad3031f4095e29d775afd243286a67b64`; run/job `32959321642/98147938829` SUCCESS; same-head CI `32959321531/98147938016` SUCCESS;
- artifact `9603335255` / `sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45` / inner manifest 13/13 PASS;
- frozen rows 47/47; false terminators 7/7; true headers exact 40/40; native/oracle mismatch 0;
- unique exact contexts 16; tags Int=40; witness reselection 0; payload/second-control consumption 0/0.

## CLOSED CONTRACT — R3.18AT Outcome A
- contract `docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json` / `sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5`;
- membership `exact_tuple_only`; 16 complete eight-field tuples; exact observed multiplicities sum 40;
- `is_rl_223` is an explicit required field; all 7 false AQ rows remain outside header membership;
- AJ/Z/P inheritance, tag/component/Cartesian/versionless/RL223-drop-or-flip/fabricated membership are rejected.

## ACTIVE PRODUCTION GATE — R3.18AU
- validate/recompute one exact published R3.18AQ mixed-control prior;
- false remains a successful no-header terminator and may perform zero following-header/post-AQ reads;
- true may compose exactly one stateless following header only under exact R3.18AT membership;
- stop true path exactly at `payload_start`;
- consume zero following-payload bits and zero second-later-control bits.

## CLOSED
- any following-header success on the 7 false terminator rows;
- any following-header context outside exact R3.18AT membership;
- following payload after the R3.18AU true header `payload_start`;
- second later property-control bit after the R3.18AU header;
- repeated/generalized property loop or generic cursor;
- next actor/frame/lifecycle/raw-state/event/replay-slice/skill/counterfactual/runtime/export widening.

---

"""
t = prefix + override + "# 1. Status vocabulary" + tail
write(p, t)

# 5) Machine continuity state
p = "docs/continuity/MIMIR_CONTINUITY_STATE.json"
state = json.loads(read(p))
state["updated_date"] = "2026-08-26"
state["last_completed_read_only_audit"] = "R3.18AS"
state["last_completed_evidence_pass"] = "R3.18AS"
state["last_completed_evidence_outcome"] = "A — frozen 47-row mixed lane preserved; false terminators 7/7; true following headers exact 40/40; 16 exact eight-field contexts; Int=40; mismatch/reselection 0/0; payload/second-control 0/0; artifact 9603335255."
state["last_completed_contract_pass"] = "R3.18AT"
state["last_completed_contract_outcome"] = f"A — exact_tuple_only 16 complete eight-field contexts; multiplicity sum 40; 7 false terminators outside membership; contract sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5."
state["current_pass"] = "R3.18AU"
state["current_pass_kind"] = "bounded production implementation / mixed post-AQ following-header composition under exact R3.18AT contract"
state["current_pass_goal"] = "Validate/recompute one published R3.18AQ prior. Preserve false as a no-header terminator with zero post-AQ reads. On true only, compose exactly one following header using the existing stateless primitive, require exact R3.18AT eight-field membership, and stop at payload_start."
state["current_pass_stop_boundary"] = "False stops at the existing AQ boundary. True stops exactly at following-header payload_start. No following payload, second later control, generic/repeated cursor, actor/frame/lifecycle/raw-state/event/skill/runtime widening."

closed = list(state.get("closed_now", []))
obsolete = "production following-header composition before R3.18AT exact-context contract admission"
closed = [x for x in closed if x != obsolete]
for item in [
    "post-AQ following-header contexts outside exact R3.18AT membership",
    "following-header success on any R3.18AQ false terminator",
    "following payload after the one R3.18AU following header payload_start",
    "second later property control bit after R3.18AU",
    "generalized/repeated property loop or generic cursor after R3.18AU",
]:
    if item not in closed:
        closed.append(item)
state["closed_now"] = closed

nfr = list(state.get("next_files_to_read", []))
anchor = "docs/continuity/MIMIR_R3_18AT_EXECUTION_SPEC.md"
if anchor not in nfr:
    raise SystemExit("state next_files anchor missing")
i = nfr.index(anchor) + 1
for item in [
    "docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json",
    "docs/continuity/MIMIR_R3_18AT_DECISION.md",
    "docs/continuity/MIMIR_R3_18AU_EXECUTION_SPEC.md",
]:
    if item not in nfr:
        nfr.insert(i, item)
        i += 1
state["next_files_to_read"] = nfr
state["r3_18at"] = {
    "outcome": "A — admitted / boundary-specific exact-eight-field contract",
    "production_source_changed": False,
    "canonical_main_before_admission": BASE_SHA,
    "canonical_tree_before_admission": BASE_TREE,
    "production_sha": PROD_SHA,
    "production_tree": PROD_TREE,
    "source_evidence_pass": "R3.18AS",
    "source_evidence_head": "475650fea59332f74b9f69da50e3e4471622ab7e",
    "source_artifact_id": 9603335255,
    "source_artifact_sha256": "0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45",
    "contract_file": "docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json",
    "contract_sha256": CONTRACT_SHA,
    "membership_policy": "exact_tuple_only",
    "tuple_field_count": 8,
    "frozen_lane_rows": 47,
    "false_terminators": 7,
    "observed_header_rows": 40,
    "unique_exact_contexts": 16,
    "observed_multiplicity_sum": 40,
    "observed_tag_counts": {"Int": 40},
    "is_rl_223_required": True,
    "older_contract_inheritance": False,
    "production_mutation": False,
    "following_payload_bits_consumed": 0,
    "second_later_control_bits_consumed": 0,
    "next_pass": "R3.18AU"
}
write(p, json.dumps(state, indent=2, ensure_ascii=False))

# 6) Current state summary
current_state = f"""# MIMIR — Current Canonical State

**Continuity date:** 2026-08-26
**Repository:** `Naveax/MIMIR`
**Canonical production SHA:** `e1ccbef95c8424b689dee7d77fd8fde2af3e0204`
**Production tree:** `4e7100625096594bcc5c5b4c6a8054c283643b13`
**Production milestone:** `R3.18AQ — bounded post-AN mixed following-control production`
**Last read-only evidence:** `R3.18AS — Outcome A / false terminators 7/7 / true headers exact 40/40 / 16 exact eight-field contexts / Int=40 / artifact 9603335255`
**Last completed contract:** `R3.18AT — exact_tuple_only / 16 eight-field contexts / multiplicity 40 / 7 false terminators outside membership / sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5`
**Current exact pass:** `R3.18AU — bounded post-AQ mixed-continuation following-header production`

## Truthful boundary

R3.18AQ remains canonical production. R3.18AS proved exactly one following header on the immutable forty true continuation rows while preserving seven false terminators. R3.18AT freezes only the sixteen complete eight-field tuples observed there.

```text
AS evidence head/tree                 475650fea59332f74b9f69da50e3e4471622ab7e / 1303071ad3031f4095e29d775afd243286a67b64
AS artifact                           9603335255 / sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45
AS false / true                       7 / 40
AS exact true headers                 40/40
AS native/oracle mismatch             0
AT contract                           sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5
AT membership                         exact_tuple_only
AT exact contexts                     16/16
AT multiplicity sum                   40
AT tuple fields                       bound,width,object,tag,version major/minor,net version,is_rl_223
AT false terminators in membership    0 / 7 remain terminators
AT AJ/Z/P inheritance                 false/false/false
production mutation                   0
```

## Current gate

R3.18AU is a bounded production implementation. It must recompute/validate the supplied AQ prior. A false AQ result stays a successful terminator and must not perform header lookup. A true AQ result may compose exactly one following header using the existing stateless primitive only if the complete header context is an exact R3.18AT member, then must stop at `payload_start`.

## Hard stop

Do not decode the following payload, read a second later control, admit a context outside R3.18AT, synthesize a header for a false terminator, drop/flip the RL223 field, create a generalized/repeated property cursor, or widen actor/frame/lifecycle/raw-state/event/replay-slice/skill/runtime/export behavior.
"""
write("docs/continuity/MIMIR_CURRENT_STATE.md", current_state)

# 7) Handoff
handoff = f"""# MIMIR — Next Chat Handoff

Canonical production is **R3.18AQ** at `e1ccbef95c8424b689dee7d77fd8fde2af3e0204` / `4e7100625096594bcc5c5b4c6a8054c283643b13`. R3.18AS is closed Outcome A as read-only following-header evidence and R3.18AT is closed Outcome A as an exact-context contract.

R3.18AT contract authority: `docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json` / `sha256:3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5`. Membership is exact tuple equality over `(stream_id_bound, prop_id_bits, property_object_index, attribute_tag, version_major, version_minor, net_version, is_rl_223)`. Exactly 16 contexts are admitted with multiplicities summing to 40. All observed headers are `Int`. The exact seven AQ-false rows remain terminators and are outside header membership.

Source evidence remains R3.18AS: evidence `475650fea59332f74b9f69da50e3e4471622ab7e`; run/job `32959321642/98147938829` SUCCESS; same-head CI `32959321531/98147938016` SUCCESS; artifact `9603335255` / `sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45`; frozen 47 rows / false=7 / true=40 / exact true headers 40/40 / mismatch 0 / payload-control consumption 0/0. AS canonical publication helper `32967201830/98172273710` succeeded.

The active pass is **R3.18AU bounded production**. Validate/recompute one published AQ prior. False must remain a no-header terminator with zero post-AQ reads. True may invoke the existing stateless following-header primitive once, must require exact R3.18AT membership, and must stop at `payload_start`.

Do not decode the following payload, read another control bit, admit any context outside the exact AT set, or create a generic/repeated property loop. Before any workflow dispatch/rerun inspect queued/waiting/in-progress equivalent runs and reuse an existing exact run. Rerun is never polling.
"""
write("docs/continuity/MIMIR_NEXT_CHAT_HANDOFF.md", handoff)

# 8) Progress ledger append
p = "docs/continuity/MIMIR_PROGRESS_LEDGER.md"
t = read(p).rstrip()
entry = f"""
## 2026-08-26 — R3.18AT — Post-AQ Mixed-Continuation Following-Header Exact-Context Contract

Production base SHA: `e1ccbef95c8424b689dee7d77fd8fde2af3e0204`
Production commit SHA: unchanged
Pass type: contract-only admission
Outcome: **A — ADMITTED / COMPLETE**

What changed:
- no production Rust changed;
- converted the immutable R3.18AS following-header observation into one boundary-specific exact membership contract;
- admitted exactly 16 complete eight-field tuples with exact observed multiplicities summing to 40;
- preserved all 7 false R3.18AQ rows as terminators outside header membership;
- retained `is_rl_223` as an explicit required tuple field.

Authority:
- canonical main before admission `b8e9bb465bd49974ca23e00c42ea29d59beecb39` / tree `7480a997259b5f77a88e1326da2ccfbebe801f80`;
- AS evidence `475650fea59332f74b9f69da50e3e4471622ab7e` / run/job `32959321642/98147938829` SUCCESS;
- AS artifact `9603335255` / `sha256:0642a4c6c6e57edad8e23dc93bdff96f54ed9563633ebe63c332a8ecbac40a45` / manifest 13/13 PASS;
- AS canonical publication `32967201830/98172273710` SUCCESS / receipt `9606191056`;
- contract `docs/continuity/MIMIR_R3_18AT_ADMITTED_HEADER_CONTEXTS.json`;
- contract SHA-256 `3c412a5fdf5ed647fbe2b2e4db1f3adf4e4f578ae07c58a302c261f6abafd0a5`.

Validation:
- exact tuple equality PASS 16/16;
- exact multiplicity equality PASS 16/16 / sum 40;
- 7/7 false terminators remain outside membership;
- tag-only, component-only, Cartesian, versionless, RL223-drop/flip, fabricated seventeenth and AJ-valid-but-AT-absent membership reject;
- AJ/Z/P cross-boundary inheritance false;
- production/Cargo/fixture/corpus/support mutation 0/0/0/0/0.

Boundaries opened:
- bounded production composition of exactly one following header on an AQ-true result under exact R3.18AT membership; false remains a no-header terminator.

Boundaries still closed:
- following payload; second later property control; contexts outside exact AT membership; header synthesis on false terminators; generalized/repeated property loop/cursor; wider semantic/runtime layers.

Next exact pass:
- `R3.18AU — bounded post-AQ mixed-continuation following-header production`.
"""
write(p, t + "\n\n" + entry.strip())

print("R3.18AT continuity generator complete")
